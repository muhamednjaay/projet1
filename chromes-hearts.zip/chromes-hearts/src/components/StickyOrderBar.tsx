"use client";

import { SITE_CONFIG } from "@/lib/constants";
import { trackPixelEvent } from "@/lib/fbpixel";

/**
 * Barre flottante visible en permanence sur mobile pour maximiser
 * la conversion des visiteurs venus des publicités Facebook/Instagram.
 */
export function StickyOrderBar() {
  return (
    <div className="fixed inset-x-0 bottom-0 z-40 border-t border-or/20 bg-noir/95 p-3 backdrop-blur-md sm:hidden">
      <div className="flex items-center justify-between gap-3">
        <div className="leading-tight">
          <p className="font-display text-base font-semibold text-or">
            {SITE_CONFIG.price.toLocaleString("fr-FR")} {SITE_CONFIG.currency}
          </p>
          <p className="font-body text-[11px] text-creme-dim line-through">
            {SITE_CONFIG.oldPrice.toLocaleString("fr-FR")} {SITE_CONFIG.currency}
          </p>
        </div>
        <a
          href="#commande"
          onClick={() => trackPixelEvent("InitiateCheckout")}
          className="btn-gold px-6 py-3 text-xs"
        >
          Commander
        </a>
      </div>
    </div>
  );
}
