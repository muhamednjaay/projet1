"use client";

import { useEffect, useState } from "react";
import Image from "next/image";
import { GALLERY_IMAGES } from "@/lib/constants";
import { useReveal } from "@/lib/useReveal";

export function Gallery() {
  const [activeIndex, setActiveIndex] = useState<number | null>(null);
  const revealRef = useReveal<HTMLDivElement>();

  const close = () => setActiveIndex(null);
  const showPrev = () =>
    setActiveIndex((i) => (i === null ? null : (i - 1 + GALLERY_IMAGES.length) % GALLERY_IMAGES.length));
  const showNext = () =>
    setActiveIndex((i) => (i === null ? null : (i + 1) % GALLERY_IMAGES.length));

  // Navigation clavier dans la visionneuse
  useEffect(() => {
    if (activeIndex === null) return;
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") close();
      if (e.key === "ArrowLeft") showPrev();
      if (e.key === "ArrowRight") showNext();
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [activeIndex]);

  return (
    <section id="galerie" className="container-page py-24 sm:py-32">
      <div ref={revealRef} className="reveal mb-14 text-center">
        <p className="eyebrow mb-3">La collection en images</p>
        <h2 className="font-display text-3xl font-medium text-creme sm:text-4xl">
          Chaque détail, sous tous les angles
        </h2>
      </div>

      <div className="grid grid-cols-2 gap-3 sm:gap-4 md:grid-cols-3">
        {GALLERY_IMAGES.map((image, index) => (
          <button
            key={image.src}
            type="button"
            onClick={() => setActiveIndex(index)}
            className={`group relative aspect-square overflow-hidden rounded-xl border border-noir-line
              ${index === 0 ? "col-span-2 row-span-2 aspect-square md:aspect-auto" : ""}`}
            aria-label={`Agrandir : ${image.alt}`}
          >
            <Image
              src={image.src}
              alt={image.alt}
              fill
              sizes="(max-width: 768px) 50vw, 33vw"
              className="object-cover transition-transform duration-700 ease-out group-hover:scale-110"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-noir/40 via-transparent to-transparent opacity-0 transition-opacity duration-300 group-hover:opacity-100" />
            <span className="absolute bottom-3 right-3 rounded-full border border-or/50 bg-noir/70 px-2 py-1 text-[10px] uppercase tracking-widest text-or opacity-0 transition-opacity duration-300 group-hover:opacity-100">
              Zoom
            </span>
          </button>
        ))}
      </div>

      {/* Visionneuse plein écran */}
      {activeIndex !== null && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-noir/95 p-4 backdrop-blur-sm"
          role="dialog"
          aria-modal="true"
          onClick={close}
        >
          <button
            type="button"
            onClick={close}
            className="absolute right-5 top-5 rounded-full border border-or/40 p-2 text-creme transition-colors hover:border-or hover:text-or"
            aria-label="Fermer la visionneuse"
          >
            <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth={1.5}>
              <path d="M6 6l12 12M18 6L6 18" strokeLinecap="round" />
            </svg>
          </button>

          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              showPrev();
            }}
            className="absolute left-3 top-1/2 -translate-y-1/2 rounded-full border border-or/40 p-3 text-creme transition-colors hover:border-or hover:text-or sm:left-8"
            aria-label="Image précédente"
          >
            <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth={1.5}>
              <path d="M15 6l-6 6 6 6" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </button>

          <div
            className="relative aspect-square w-full max-w-xl animate-fade-up"
            onClick={(e) => e.stopPropagation()}
          >
            <Image
              src={GALLERY_IMAGES[activeIndex].src}
              alt={GALLERY_IMAGES[activeIndex].alt}
              fill
              sizes="90vw"
              className="rounded-2xl object-contain"
            />
          </div>

          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              showNext();
            }}
            className="absolute right-3 top-1/2 -translate-y-1/2 rounded-full border border-or/40 p-3 text-creme transition-colors hover:border-or hover:text-or sm:right-8"
            aria-label="Image suivante"
          >
            <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth={1.5}>
              <path d="M9 6l6 6-6 6" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </button>
        </div>
      )}
    </section>
  );
}
