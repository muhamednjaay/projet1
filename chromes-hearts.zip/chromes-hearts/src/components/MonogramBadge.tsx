interface MonogramBadgeProps {
  className?: string;
}

/**
 * Élément signature de la marque : un sceau doré "CH" gravé,
 * inspiré des hallmarks de maroquinerie de luxe. Réutilisé dans
 * le hero, l'étiquette de prix et l'en-tête du formulaire pour
 * créer un fil conducteur visuel reconnaissable.
 */
export function MonogramBadge({ className = "" }: MonogramBadgeProps) {
  return (
    <svg
      viewBox="0 0 100 100"
      className={className}
      aria-hidden="true"
      role="presentation"
    >
      <circle
        cx="50"
        cy="50"
        r="47"
        fill="none"
        stroke="url(#monogram-ring)"
        strokeWidth="1.5"
      />
      <circle
        cx="50"
        cy="50"
        r="40"
        fill="none"
        stroke="url(#monogram-ring)"
        strokeWidth="0.75"
        opacity="0.6"
      />
      <text
        x="50"
        y="60"
        textAnchor="middle"
        fontFamily="var(--font-fraunces), serif"
        fontSize="34"
        fill="url(#monogram-ring)"
        fontWeight="600"
      >
        CH
      </text>
      <defs>
        <linearGradient id="monogram-ring" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#8b6f1f" />
          <stop offset="45%" stopColor="#e8cf7a" />
          <stop offset="70%" stopColor="#c9a227" />
          <stop offset="100%" stopColor="#8b6f1f" />
        </linearGradient>
      </defs>
    </svg>
  );
}
