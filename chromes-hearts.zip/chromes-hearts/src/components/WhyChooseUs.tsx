"use client";

import { FEATURES } from "@/lib/constants";
import { FeatureIcon } from "@/components/FeatureIcon";
import { useReveal } from "@/lib/useReveal";

function FeatureCard({ feature, index }: { feature: (typeof FEATURES)[number]; index: number }) {
  const ref = useReveal<HTMLDivElement>();
  return (
    <div
      ref={ref}
      className="reveal card-surface flex flex-col gap-4 p-7 transition-colors duration-300 hover:border-or/40"
      style={{ transitionDelay: `${index * 80}ms` }}
    >
      <div className="flex h-12 w-12 items-center justify-center rounded-full border border-or/30 text-or">
        <FeatureIcon name={feature.icon} />
      </div>
      <h3 className="font-display text-xl font-medium text-creme">{feature.title}</h3>
      <p className="font-body text-sm leading-relaxed text-creme-muted">{feature.text}</p>
    </div>
  );
}

export function WhyChooseUs() {
  const headerRef = useReveal<HTMLDivElement>();

  return (
    <section id="pourquoi" className="bg-noir-soft py-24 sm:py-32">
      <div className="container-page">
        <div ref={headerRef} className="reveal mb-14 text-center">
          <p className="eyebrow mb-3">Ce qui nous distingue</p>
          <h2 className="text-balance font-display text-3xl font-medium text-creme sm:text-4xl">
            Pourquoi choisir CHROMÉS HEARTS
          </h2>
        </div>

        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {FEATURES.map((feature, index) => (
            <FeatureCard key={feature.title} feature={feature} index={index} />
          ))}
        </div>
      </div>
    </section>
  );
}
