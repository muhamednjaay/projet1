import { SITE_CONFIG } from "@/lib/constants";
import { MonogramBadge } from "@/components/MonogramBadge";

export function Footer() {
  return (
    <footer className="border-t border-noir-line pb-24 pt-16 sm:pb-16">
      <div className="container-page flex flex-col items-center gap-6 text-center">
        <MonogramBadge className="h-10 w-10" />
        <p className="font-display text-lg tracking-wide text-creme">{SITE_CONFIG.brand}</p>
        <p className="max-w-md font-body text-xs leading-relaxed text-creme-dim">
          Produit vendu à l&apos;unité. Paiement à la livraison. Livraison sous 24 à 72h selon la ville.
          Pochette premium offerte avec chaque commande.
        </p>
        <p className="font-body text-xs text-creme-dim">
          © {new Date().getFullYear()} {SITE_CONFIG.brand}. Tous droits réservés.
        </p>
      </div>
    </footer>
  );
}
