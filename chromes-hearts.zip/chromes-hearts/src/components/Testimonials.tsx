"use client";

import { TESTIMONIALS } from "@/lib/constants";
import { useReveal } from "@/lib/useReveal";

function StarRating({ rating }: { rating: number }) {
  return (
    <div className="flex gap-1" aria-label={`${rating} sur 5 étoiles`}>
      {Array.from({ length: 5 }).map((_, i) => (
        <svg
          key={i}
          viewBox="0 0 24 24"
          className={`h-4 w-4 ${i < rating ? "fill-or" : "fill-noir-line"}`}
          aria-hidden="true"
        >
          <path d="M12 2l2.9 6.6 7.1.6-5.4 4.7 1.6 7-6.2-3.8-6.2 3.8 1.6-7L2 9.2l7.1-.6L12 2Z" />
        </svg>
      ))}
    </div>
  );
}

function TestimonialCard({ testimonial, index }: { testimonial: (typeof TESTIMONIALS)[number]; index: number }) {
  const ref = useReveal<HTMLDivElement>();
  const initials = testimonial.name
    .split(" ")
    .map((part) => part[0])
    .join("");

  return (
    <div
      ref={ref}
      className="reveal card-surface flex h-full flex-col gap-4 p-7"
      style={{ transitionDelay: `${index * 70}ms` }}
    >
      <StarRating rating={testimonial.rating} />
      <p className="flex-1 font-body text-sm leading-relaxed text-creme-muted">
        &ldquo;{testimonial.text}&rdquo;
      </p>
      <div className="flex items-center gap-3 pt-2">
        <div className="flex h-10 w-10 items-center justify-center rounded-full border border-or/40 font-display text-sm text-or">
          {initials}
        </div>
        <div>
          <p className="font-body text-sm font-medium text-creme">{testimonial.name}</p>
          <p className="font-body text-xs text-creme-dim">{testimonial.city}</p>
        </div>
      </div>
    </div>
  );
}

export function Testimonials() {
  const headerRef = useReveal<HTMLDivElement>();

  return (
    <section id="avis" className="container-page py-24 sm:py-32">
      <div ref={headerRef} className="reveal mb-14 text-center">
        <p className="eyebrow mb-3">Ils ont commandé</p>
        <h2 className="font-display text-3xl font-medium text-creme sm:text-4xl">Avis clients</h2>
        {/*
          Pour ajouter, modifier ou retirer un avis : éditez le tableau
          TESTIMONIALS dans src/lib/constants.ts — cette section s'adapte
          automatiquement, aucune autre modification n'est nécessaire.
        */}
      </div>

      <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
        {TESTIMONIALS.map((testimonial, index) => (
          <TestimonialCard key={testimonial.name} testimonial={testimonial} index={index} />
        ))}
      </div>
    </section>
  );
}
