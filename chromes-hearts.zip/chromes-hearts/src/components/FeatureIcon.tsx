export type FeatureIconName = "design" | "comfort" | "shield" | "gift";

interface FeatureIconProps {
  name: FeatureIconName;
  className?: string;
}

/**
 * Icônes dessinées à la main en SVG — aucune dépendance externe
 * (lucide, heroicons...) n'est nécessaire pour ces 4 pictogrammes.
 */
export function FeatureIcon({ name, className = "h-7 w-7" }: FeatureIconProps) {
  const common = {
    className,
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: 1.5,
    strokeLinecap: "round" as const,
    strokeLinejoin: "round" as const,
  };

  switch (name) {
    case "design":
      return (
        <svg {...common} aria-hidden="true">
          <circle cx="7" cy="12" r="4" />
          <circle cx="17" cy="12" r="4" />
          <path d="M11 12h2" />
          <path d="M3 12h0" />
          <path d="M21 12h0" />
        </svg>
      );
    case "comfort":
      return (
        <svg {...common} aria-hidden="true">
          <path d="M4 13c0-4 2-8 8-8s8 4 8 8" />
          <path d="M4 13v3a2 2 0 0 0 2 2h1v-5H4Z" />
          <path d="M20 13v3a2 2 0 0 1-2 2h-1v-5h3Z" />
        </svg>
      );
    case "shield":
      return (
        <svg {...common} aria-hidden="true">
          <path d="M12 3l7 3v6c0 4.5-3 8-7 9-4-1-7-4.5-7-9V6l7-3Z" />
          <path d="M9.5 12.5l2 2 3.5-4" />
        </svg>
      );
    case "gift":
      return (
        <svg {...common} aria-hidden="true">
          <rect x="4" y="9" width="16" height="11" rx="1" />
          <path d="M4 13h16" />
          <path d="M12 9v11" />
          <path d="M12 9C9.5 9 8 7.8 8 6.2 8 5 9 4 10.2 4 11.6 4 12 6 12 9Z" />
          <path d="M12 9c2.5 0 4-1.2 4-2.8C16 5 15 4 13.8 4 12.4 4 12 6 12 9Z" />
        </svg>
      );
    default:
      return null;
  }
}
