"use client";

import { useState } from "react";
import { SITE_CONFIG, DISCOUNT_PERCENT } from "@/lib/constants";
import { MonogramBadge } from "@/components/MonogramBadge";
import { getQuickOrderUrl } from "@/lib/whatsapp";
import { trackPixelEvent } from "@/lib/fbpixel";

export function Hero() {
  // Si la vidéo /videos/hero.mp4 est absente ou ne peut pas être lue,
  // on bascule automatiquement sur un fond dégradé — le site reste
  // toujours pleinement fonctionnel et visuellement soigné.
  const [videoFailed, setVideoFailed] = useState(false);

  return (
    <section className="relative flex min-h-[100svh] items-center overflow-hidden bg-noir-radial">
      {/* Fond vidéo */}
      {!videoFailed && (
        <video
          className="absolute inset-0 h-full w-full object-cover opacity-45"
          autoPlay
          muted
          loop
          playsInline
          poster="/images/gallery-1.svg"
          onError={() => setVideoFailed(true)}
        >
          {/* Déposez votre fichier vidéo ici : /public/videos/hero.mp4 */}
          <source src="/videos/hero.mp4" type="video/mp4" />
        </video>
      )}

      {/* Voile de contraste pour garantir la lisibilité du texte */}
      <div className="absolute inset-0 bg-gradient-to-t from-noir via-noir/70 to-noir/40" />

      {/* Halo doré ambiant */}
      <div className="pointer-events-none absolute left-1/2 top-1/3 h-[560px] w-[560px] -translate-x-1/2 -translate-y-1/2 rounded-full bg-or/10 blur-[120px]" />

      <div className="container-page relative z-10 py-32">
        <div className="mx-auto flex max-w-3xl flex-col items-center text-center animate-fade-up">
          <MonogramBadge className="mb-8 h-16 w-16" />

          <p className="eyebrow mb-4">Édition limitée</p>

          <h1 className="text-balance font-display text-5xl font-medium leading-[1.05] tracking-tight text-creme sm:text-7xl">
            {SITE_CONFIG.brand}
          </h1>

          <p className="mt-6 max-w-xl text-balance font-body text-lg text-creme-muted sm:text-xl">
            {SITE_CONFIG.tagline}
          </p>

          {/* Bloc prix */}
          <div className="mt-10 flex flex-col items-center gap-2">
            <div className="flex items-baseline gap-4">
              <span className="font-display text-4xl font-semibold text-or sm:text-5xl">
                {SITE_CONFIG.price.toLocaleString("fr-FR")} {SITE_CONFIG.currency}
              </span>
              <span className="font-body text-lg text-creme-dim line-through">
                {SITE_CONFIG.oldPrice.toLocaleString("fr-FR")} {SITE_CONFIG.currency}
              </span>
            </div>
            <span className="rounded-full border border-or/40 px-3 py-1 text-xs uppercase tracking-widest text-or">
              -{DISCOUNT_PERCENT}% aujourd&apos;hui
            </span>
          </div>

          {/* CTA */}
          <div className="mt-10 flex flex-col items-center gap-4 sm:flex-row">
            <a
              href="#commande"
              className="btn-gold w-full sm:w-auto"
              onClick={() => trackPixelEvent("InitiateCheckout")}
            >
              Je commande maintenant
            </a>
            <a
              href={getQuickOrderUrl()}
              target="_blank"
              rel="noopener noreferrer"
              className="btn-ghost w-full sm:w-auto"
              onClick={() => trackPixelEvent("Contact")}
            >
              Commander via WhatsApp
            </a>
          </div>

          {/* Badges de réassurance */}
          <ul className="mt-12 flex flex-wrap items-center justify-center gap-x-8 gap-y-3 font-body text-sm text-creme-muted">
            {SITE_CONFIG.trustBadges.map((badge) => (
              <li key={badge} className="flex items-center gap-2">
                <span className="h-1.5 w-1.5 rounded-full bg-or" />
                {badge}
              </li>
            ))}
          </ul>
        </div>
      </div>

      {/* Indicateur de scroll */}
      <div className="absolute bottom-8 left-1/2 z-10 -translate-x-1/2 animate-fade-up">
        <div className="flex h-9 w-6 items-start justify-center rounded-full border border-or/40 p-1.5">
          <span className="h-1.5 w-1.5 animate-pulse-ring rounded-full bg-or" />
        </div>
      </div>
    </section>
  );
}
