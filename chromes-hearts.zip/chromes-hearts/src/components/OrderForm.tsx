"use client";

import { FormEvent, ReactNode, useState } from "react";
import { SITE_CONFIG } from "@/lib/constants";
import { buildGoogleMapsLink, buildOrderMessage, getWhatsAppUrl } from "@/lib/whatsapp";
import { trackPixelEvent } from "@/lib/fbpixel";
import { MonogramBadge } from "@/components/MonogramBadge";
import { useReveal } from "@/lib/useReveal";

type GeoStatus = "idle" | "loading" | "success" | "error";

interface FormErrors {
  name?: string;
  phone?: string;
  city?: string;
  district?: string;
}

export function OrderForm() {
  const revealRef = useReveal<HTMLDivElement>();

  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [city, setCity] = useState("");
  const [district, setDistrict] = useState("");
  const [address, setAddress] = useState("");
  const [quantity, setQuantity] = useState(1);

  const [geoStatus, setGeoStatus] = useState<GeoStatus>("idle");
  const [gpsLink, setGpsLink] = useState<string | null>(null);
  const [errors, setErrors] = useState<FormErrors>({});

  const total = SITE_CONFIG.price * quantity;

  function handleUseLocation() {
    if (!("geolocation" in navigator)) {
      setGeoStatus("error");
      return;
    }

    setGeoStatus("loading");

    navigator.geolocation.getCurrentPosition(
      (position) => {
        const { latitude, longitude } = position.coords;
        setGpsLink(buildGoogleMapsLink(latitude, longitude));
        setGeoStatus("success");
      },
      () => {
        // Refusée ou indisponible : le client garde la main pour saisir
        // son adresse manuellement, le formulaire reste utilisable.
        setGeoStatus("error");
        setGpsLink(null);
      },
      { enableHighAccuracy: true, timeout: 10000 }
    );
  }

  function validate(): boolean {
    const nextErrors: FormErrors = {};
    if (!name.trim()) nextErrors.name = "Merci d'indiquer votre nom.";
    if (!phone.trim() || phone.replace(/\D/g, "").length < 8) {
      nextErrors.phone = "Merci d'indiquer un numéro de téléphone valide.";
    }
    if (!city.trim()) nextErrors.city = "Merci d'indiquer votre ville.";
    if (!district.trim()) nextErrors.district = "Merci d'indiquer votre quartier.";

    setErrors(nextErrors);
    return Object.keys(nextErrors).length === 0;
  }

  function handleSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (!validate()) return;

    const message = buildOrderMessage({
      name: name.trim(),
      phone: phone.trim(),
      city: city.trim(),
      district: district.trim(),
      address: address.trim(),
      gpsLink,
      quantity,
    });

    trackPixelEvent("Lead", { value: total, currency: "XOF" });

    // Ouvre WhatsApp avec le message pré-rempli — il ne reste plus
    // au client qu'à appuyer sur "Envoyer".
    window.open(getWhatsAppUrl(message), "_blank", "noopener,noreferrer");
  }

  return (
    <section id="commande" className="container-page py-24 sm:py-32">
      <div ref={revealRef} className="reveal mx-auto max-w-2xl">
        <div className="mb-10 text-center">
          <MonogramBadge className="mx-auto mb-6 h-12 w-12" />
          <p className="eyebrow mb-3">Dernière étape</p>
          <h2 className="font-display text-3xl font-medium text-creme sm:text-4xl">Passez votre commande</h2>
          <p className="mt-4 font-body text-sm text-creme-muted">
            Remplissez le formulaire : un message WhatsApp pré-rempli s&apos;ouvrira automatiquement, il ne
            vous restera qu&apos;à l&apos;envoyer.
          </p>
        </div>

        <form onSubmit={handleSubmit} noValidate className="card-surface flex flex-col gap-6 p-6 sm:p-9">
          {/* Récapitulatif prix / quantité */}
          <div className="flex items-center justify-between rounded-xl border border-or/20 bg-noir/40 px-5 py-4">
            <div>
              <p className="font-display text-lg text-creme">{SITE_CONFIG.brand}</p>
              <p className="font-body text-xs text-creme-dim">Pochette premium offerte</p>
            </div>
            <div className="flex items-center gap-3">
              <label htmlFor="quantity" className="sr-only">
                Quantité
              </label>
              <div className="flex items-center rounded-full border border-noir-line">
                <button
                  type="button"
                  onClick={() => setQuantity((q) => Math.max(1, q - 1))}
                  className="px-3 py-1.5 text-creme-muted transition-colors hover:text-or"
                  aria-label="Diminuer la quantité"
                >
                  −
                </button>
                <span id="quantity" className="w-6 text-center font-body text-sm text-creme">
                  {quantity}
                </span>
                <button
                  type="button"
                  onClick={() => setQuantity((q) => Math.min(9, q + 1))}
                  className="px-3 py-1.5 text-creme-muted transition-colors hover:text-or"
                  aria-label="Augmenter la quantité"
                >
                  +
                </button>
              </div>
            </div>
          </div>

          <div className="flex items-baseline justify-between border-b border-noir-line pb-4">
            <span className="font-body text-sm text-creme-muted">Total</span>
            <span className="font-display text-2xl font-semibold text-or">
              {total.toLocaleString("fr-FR")} {SITE_CONFIG.currency}
            </span>
          </div>

          {/* Champs du formulaire */}
          <div className="grid gap-5 sm:grid-cols-2">
            <Field label="Nom complet" htmlFor="name" error={errors.name}>
              <input
                id="name"
                type="text"
                autoComplete="name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Ex : Awa Ndiaye"
                className="field-input"
              />
            </Field>

            <Field label="Téléphone" htmlFor="phone" error={errors.phone}>
              <input
                id="phone"
                type="tel"
                autoComplete="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="Ex : 77 123 45 67"
                className="field-input"
              />
            </Field>

            <Field label="Ville" htmlFor="city" error={errors.city}>
              <input
                id="city"
                type="text"
                autoComplete="address-level2"
                value={city}
                onChange={(e) => setCity(e.target.value)}
                placeholder="Ex : Dakar"
                className="field-input"
              />
            </Field>

            <Field label="Quartier" htmlFor="district" error={errors.district}>
              <input
                id="district"
                type="text"
                value={district}
                onChange={(e) => setDistrict(e.target.value)}
                placeholder="Ex : Sacré-Cœur"
                className="field-input"
              />
            </Field>
          </div>

          <Field label="Adresse précise (facultatif si position partagée)" htmlFor="address">
            <textarea
              id="address"
              rows={2}
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              placeholder="Ex : Villa n°12, non loin de la pharmacie..."
              className="field-input resize-none"
            />
          </Field>

          {/* Géolocalisation */}
          <div className="rounded-xl border border-dashed border-or/30 p-5">
            <button
              type="button"
              onClick={handleUseLocation}
              disabled={geoStatus === "loading"}
              className="flex w-full items-center justify-center gap-2 rounded-full border border-or/40 px-5 py-3 font-body text-sm font-medium text-or transition-colors hover:bg-or/10 disabled:opacity-60"
            >
              <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth={1.5}>
                <path d="M12 21s7-6.2 7-11a7 7 0 1 0-14 0c0 4.8 7 11 7 11Z" strokeLinecap="round" strokeLinejoin="round" />
                <circle cx="12" cy="10" r="2.4" />
              </svg>
              {geoStatus === "loading" ? "Localisation en cours..." : "Utiliser ma position actuelle"}
            </button>

            {geoStatus === "success" && gpsLink && (
              <p className="mt-3 text-center font-body text-xs text-creme-muted">
                Position enregistrée ✓{" "}
                <a href={gpsLink} target="_blank" rel="noopener noreferrer" className="text-or underline">
                  voir sur Google Maps
                </a>
              </p>
            )}
            {geoStatus === "error" && (
              <p className="mt-3 text-center font-body text-xs text-creme-dim">
                Position non partagée — pas de souci, indiquez simplement votre adresse ci-dessus.
              </p>
            )}
          </div>

          <button type="submit" className="btn-gold w-full">
            Envoyer ma commande sur WhatsApp
          </button>

          <p className="text-center font-body text-xs text-creme-dim">
            En validant, WhatsApp s&apos;ouvre avec votre commande déjà rédigée. Il vous suffira d&apos;appuyer
            sur envoyer.
          </p>
        </form>
      </div>
    </section>
  );
}

function Field({
  label,
  htmlFor,
  error,
  children,
}: {
  label: string;
  htmlFor: string;
  error?: string;
  children: ReactNode;
}) {
  return (
    <div className="flex flex-col gap-2">
      <label htmlFor={htmlFor} className="font-body text-xs uppercase tracking-wider text-creme-muted">
        {label}
      </label>
      {children}
      {error && <span className="font-body text-xs text-red-400">{error}</span>}
    </div>
  );
}
