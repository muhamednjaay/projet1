"use client";

import { useEffect, useState } from "react";
import { SITE_CONFIG } from "@/lib/constants";

const NAV_LINKS = [
  { href: "#galerie", label: "Galerie" },
  { href: "#pourquoi", label: "Pourquoi nous" },
  { href: "#avis", label: "Avis" },
  { href: "#faq", label: "FAQ" },
];

export function Header() {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className={`fixed inset-x-0 top-0 z-30 transition-all duration-300 ${
        scrolled ? "border-b border-noir-line bg-noir/90 backdrop-blur-md" : "bg-transparent"
      }`}
    >
      <div className="container-page flex items-center justify-between py-4">
        <a href="#top" className="font-display text-sm tracking-[0.25em] text-creme">
          {SITE_CONFIG.brand}
        </a>

        <nav className="hidden items-center gap-8 sm:flex">
          {NAV_LINKS.map((link) => (
            <a
              key={link.href}
              href={link.href}
              className="font-body text-xs uppercase tracking-widest text-creme-muted transition-colors hover:text-or"
            >
              {link.label}
            </a>
          ))}
        </nav>

        <a href="#commande" className="btn-ghost px-5 py-2.5 text-xs">
          Commander
        </a>
      </div>
    </header>
  );
}
