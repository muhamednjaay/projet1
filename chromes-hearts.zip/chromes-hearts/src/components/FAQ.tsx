"use client";

import { useState } from "react";
import { FAQS } from "@/lib/constants";
import { useReveal } from "@/lib/useReveal";

function FAQItem({ item, isOpen, onToggle }: { item: (typeof FAQS)[number]; isOpen: boolean; onToggle: () => void }) {
  return (
    <div className="border-b border-noir-line">
      <button
        type="button"
        onClick={onToggle}
        className="flex w-full items-center justify-between gap-4 py-6 text-left"
        aria-expanded={isOpen}
      >
        <span className="font-display text-base font-medium text-creme sm:text-lg">{item.question}</span>
        <span
          className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-full border border-or/40 text-or transition-transform duration-300 ${
            isOpen ? "rotate-45" : ""
          }`}
          aria-hidden="true"
        >
          <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth={1.5}>
            <path d="M12 5v14M5 12h14" strokeLinecap="round" />
          </svg>
        </span>
      </button>

      {/* Animation de hauteur via grid-template-rows : fluide, sans mesure JS */}
      <div
        className="grid transition-[grid-template-rows] duration-300 ease-out"
        style={{ gridTemplateRows: isOpen ? "1fr" : "0fr" }}
      >
        <div className="overflow-hidden">
          <p className="pb-6 font-body text-sm leading-relaxed text-creme-muted">{item.answer}</p>
        </div>
      </div>
    </div>
  );
}

export function FAQ() {
  const [openIndex, setOpenIndex] = useState<number | null>(0);
  const headerRef = useReveal<HTMLDivElement>();

  return (
    <section id="faq" className="bg-noir-soft py-24 sm:py-32">
      <div className="container-page max-w-3xl">
        <div ref={headerRef} className="reveal mb-12 text-center">
          <p className="eyebrow mb-3">Questions fréquentes</p>
          <h2 className="font-display text-3xl font-medium text-creme sm:text-4xl">Tout savoir avant de commander</h2>
        </div>

        <div>
          {FAQS.map((item, index) => (
            <FAQItem
              key={item.question}
              item={item}
              isOpen={openIndex === index}
              onToggle={() => setOpenIndex(openIndex === index ? null : index)}
            />
          ))}
        </div>
      </div>
    </section>
  );
}
