"use client";

import { useEffect, useRef } from "react";

/**
 * Ajoute la classe "is-visible" (voir globals.css > .reveal) dès qu'un
 * élément entre dans le viewport. Remplace une librairie d'animation
 * complète pour un simple effet d'apparition au scroll.
 */
export function useReveal<T extends HTMLElement>() {
  const ref = useRef<T | null>(null);

  useEffect(() => {
    const node = ref.current;
    if (!node) return;

    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("is-visible");
          observer.unobserve(entry.target);
        }
      },
      { threshold: 0.15 }
    );

    observer.observe(node);
    return () => observer.disconnect();
  }, []);

  return ref;
}
