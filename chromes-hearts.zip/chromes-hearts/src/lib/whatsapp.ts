import { SITE_CONFIG } from "@/lib/constants";

/**
 * Données collectées depuis le formulaire de commande.
 */
export interface OrderFormData {
  name: string;
  phone: string;
  city: string;
  district: string;
  address: string;
  gpsLink: string | null;
  quantity: number;
}

/**
 * Construit le message de commande pré-rempli envoyé sur WhatsApp.
 * Le format respecte exactement la structure demandée par la marque.
 */
export function buildOrderMessage(data: OrderFormData): string {
  const total = SITE_CONFIG.price * data.quantity;

  const lines = [
    "Bonjour,",
    `Je souhaite commander les lunettes ${SITE_CONFIG.brand}.`,
    "",
    `Nom : ${data.name}`,
    `Téléphone : ${data.phone}`,
    `Ville : ${data.city}`,
    `Quartier : ${data.district}`,
    `Adresse : ${data.address || "Non précisée"}`,
    `Position GPS : ${data.gpsLink || "Non partagée"}`,
    `Quantité : ${data.quantity}`,
    `Prix : ${total.toLocaleString("fr-FR")} ${SITE_CONFIG.currency}`,
    "",
    "Je confirme ma commande.",
  ];

  return lines.join("\n");
}

/**
 * Construit l'URL wa.me prête à ouvrir, message déjà encodé.
 */
export function getWhatsAppUrl(message: string, phoneNumber: string = SITE_CONFIG.whatsappNumber): string {
  const sanitizedNumber = phoneNumber.replace(/\D/g, "");
  return `https://wa.me/${sanitizedNumber}?text=${encodeURIComponent(message)}`;
}

/**
 * Message court utilisé par la barre flottante WhatsApp (commande express,
 * sans passer par le formulaire) — pratique pour les visiteurs pressés.
 */
export function getQuickOrderUrl(): string {
  const message = [
    "Bonjour,",
    `Je souhaite commander les lunettes ${SITE_CONFIG.brand} au prix de ${SITE_CONFIG.price.toLocaleString(
      "fr-FR"
    )} ${SITE_CONFIG.currency}.`,
    "Merci de me recontacter pour finaliser ma commande.",
  ].join("\n");

  return getWhatsAppUrl(message);
}

/**
 * Construit un lien Google Maps à partir d'une latitude/longitude.
 */
export function buildGoogleMapsLink(latitude: number, longitude: number): string {
  return `https://www.google.com/maps?q=${latitude},${longitude}`;
}
