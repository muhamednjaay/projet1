/**
 * Petit wrapper sécurisé autour de `window.fbq` (Meta Pixel).
 * N'a aucun effet si le Pixel n'est pas configuré ou pas encore chargé.
 */

declare global {
  interface Window {
    fbq?: (...args: unknown[]) => void;
  }
}

type StandardEvent = "PageView" | "Lead" | "InitiateCheckout" | "Contact";

export function trackPixelEvent(event: StandardEvent, params?: Record<string, unknown>): void {
  if (typeof window === "undefined" || typeof window.fbq !== "function") return;
  window.fbq("track", event, params);
}
