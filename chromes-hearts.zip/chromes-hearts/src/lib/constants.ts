/**
 * ============================================================
 * CONFIGURATION CENTRALE — CHROMÉS HEARTS
 * ------------------------------------------------------------
 * Toutes les valeurs "métier" du site (prix, textes, avis,
 * questions fréquentes, numéro WhatsApp...) sont centralisées
 * ici. Modifiez ce fichier pour mettre à jour le site sans
 * toucher aux composants.
 * ============================================================
 */

export const SITE_CONFIG = {
  brand: "CHROMÉS HEARTS",
  tagline: "Le détail qui fait toute la différence.",
  description:
    "CHROMÉS HEARTS — une paire de lunettes premium à l'allure intemporelle. Pochette offerte, livraison rapide, paiement à la livraison. Commandez en 2 minutes via WhatsApp.",
  url: process.env.NEXT_PUBLIC_SITE_URL || "https://chromes-hearts.vercel.app",

  // Numéro WhatsApp receveur des commandes (format international sans "+")
  whatsappNumber: process.env.NEXT_PUBLIC_WHATSAPP_NUMBER || "221771234567",

  // Tarification
  price: 8000,
  oldPrice: 12000,
  currency: "FCFA",

  // Arguments de réassurance affichés partout (hero, formulaire, sticky bar)
  trustBadges: [
    "Pochette premium offerte",
    "Livraison rapide",
    "Paiement à la livraison",
  ],
} as const;

export const DISCOUNT_PERCENT = Math.round(
  ((SITE_CONFIG.oldPrice - SITE_CONFIG.price) / SITE_CONFIG.oldPrice) * 100
);

/**
 * Section "Pourquoi choisir CHROMÉS HEARTS"
 * `icon` fait référence à une clé gérée dans <FeatureIcon />
 */
export const FEATURES = [
  {
    icon: "design" as const,
    title: "Design premium",
    text: "Une monture sculptée dans une finition mate profonde, rehaussée de détails dorés discrets. Un accessoire qui ne passe pas inaperçu.",
  },
  {
    icon: "comfort" as const,
    title: "Confort absolu",
    text: "Charnières souples, branches ajustées et poids plume : elles se portent des heures sans jamais peser sur le nez ou les tempes.",
  },
  {
    icon: "shield" as const,
    title: "Protection lumière bleue",
    text: "Verres traités anti-lumière bleue : vos yeux restent protégés face aux écrans, du matin jusqu'au soir.",
  },
  {
    icon: "gift" as const,
    title: "Pochette offerte",
    text: "Chaque commande est livrée avec sa pochette de protection premium, offerte, pour transporter vos lunettes en toute sécurité.",
  },
] as const;

/**
 * Avis clients — remplacez librement ce tableau (ajout, suppression,
 * modification) : la section s'adapte automatiquement.
 */
export const TESTIMONIALS = [
  {
    name: "Aminata D.",
    city: "Dakar",
    rating: 5,
    text: "Les lunettes sont encore plus belles en vrai que sur les photos. La pochette offerte fait vraiment classe. Livraison en 24h !",
  },
  {
    name: "Moussa K.",
    city: "Abidjan",
    rating: 5,
    text: "Très bonne qualité pour le prix. Le paiement à la livraison m'a rassuré, je recommande sans hésiter.",
  },
  {
    name: "Fatou S.",
    city: "Thiès",
    rating: 5,
    text: "Commande passée un soir sur WhatsApp, livrée le lendemain. Le confort est top, je ne les enlève plus.",
  },
  {
    name: "Ibrahima N.",
    city: "Bamako",
    rating: 4,
    text: "Très satisfait, monture solide et élégante. Petit bémol sur le délai de livraison mais le produit vaut le coup.",
  },
] as const;

/**
 * Foire aux questions
 */
export const FAQS = [
  {
    question: "Comment se déroule le paiement ?",
    answer:
      "Le paiement se fait à la livraison, en espèces, directement auprès du livreur. Aucun paiement en ligne n'est requis pour commander.",
  },
  {
    question: "Quel est le délai de livraison ?",
    answer:
      "Vos lunettes CHROMÉS HEARTS sont généralement livrées sous 24 à 72h selon votre ville, après confirmation de votre commande sur WhatsApp.",
  },
  {
    question: "La pochette est-elle vraiment offerte ?",
    answer:
      "Oui. Chaque commande inclut automatiquement la pochette de protection premium, sans coût supplémentaire.",
  },
  {
    question: "Puis-je commander sans utiliser ma position GPS ?",
    answer:
      "Bien sûr. La géolocalisation est facultative : vous pouvez toujours saisir votre ville, quartier et adresse manuellement dans le formulaire.",
  },
  {
    question: "Les verres protègent-ils vraiment des écrans ?",
    answer:
      "Oui, les verres bénéficient d'un traitement anti-lumière bleue qui filtre une partie de la lumière émise par les écrans (téléphone, ordinateur, télévision).",
  },
  {
    question: "Comment passer commande ?",
    answer:
      "Remplissez le formulaire de commande ci-dessous puis validez : un message WhatsApp pré-rempli s'ouvre automatiquement, il ne vous reste qu'à l'envoyer.",
  },
] as const;

/**
 * Galerie produit — remplacez ces chemins par vos vraies photos
 * (mêmes dimensions conseillées : carré ou 4:5) dans /public/images
 */
export const GALLERY_IMAGES = [
  { src: "/images/gallery-1.svg", alt: "CHROMÉS HEARTS — vue de face" },
  { src: "/images/gallery-2.svg", alt: "CHROMÉS HEARTS — vue de trois quarts" },
  { src: "/images/gallery-3.svg", alt: "CHROMÉS HEARTS — détail de la charnière dorée" },
  { src: "/images/gallery-4.svg", alt: "CHROMÉS HEARTS — vue de profil" },
  { src: "/images/gallery-5.svg", alt: "CHROMÉS HEARTS — portée, gros plan" },
  { src: "/images/gallery-6.svg", alt: "CHROMÉS HEARTS — avec la pochette offerte" },
] as const;
