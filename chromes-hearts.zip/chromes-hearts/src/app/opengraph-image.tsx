import { ImageResponse } from "next/og";
import { SITE_CONFIG } from "@/lib/constants";

export const runtime = "edge";
export const size = { width: 1200, height: 630 };
export const contentType = "image/png";

export default async function OpengraphImage() {
  return new ImageResponse(
    (
      <div
        style={{
          width: "100%",
          height: "100%",
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          justifyContent: "center",
          background: "linear-gradient(135deg, #0a0a0a 0%, #1a1814 100%)",
          fontFamily: "serif",
        }}
      >
        <div
          style={{
            display: "flex",
            width: 120,
            height: 120,
            borderRadius: "50%",
            border: "3px solid #c9a227",
            alignItems: "center",
            justifyContent: "center",
            marginBottom: 32,
            color: "#e8cf7a",
            fontSize: 52,
            fontWeight: 700,
          }}
        >
          CH
        </div>
        <div
          style={{
            fontSize: 78,
            color: "#f5f1e8",
            letterSpacing: 6,
            fontWeight: 700,
          }}
        >
          {SITE_CONFIG.brand}
        </div>
        <div style={{ fontSize: 28, color: "#c9a227", marginTop: 20 }}>
          {SITE_CONFIG.tagline}
        </div>
        <div style={{ fontSize: 24, color: "#8a8578", marginTop: 36 }}>
          {SITE_CONFIG.price.toLocaleString("fr-FR")} {SITE_CONFIG.currency} — Livraison rapide — Paiement à la livraison
        </div>
      </div>
    ),
    { ...size }
  );
}
