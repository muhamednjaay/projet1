import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import { Fraunces, Inter } from "next/font/google";
import "./globals.css";
import { SITE_CONFIG } from "@/lib/constants";
import { MetaPixel } from "@/components/MetaPixel";

const fraunces = Fraunces({
  subsets: ["latin"],
  variable: "--font-fraunces",
  weight: ["400", "500", "600", "700"],
  display: "swap",
});

const inter = Inter({
  subsets: ["latin"],
  variable: "--font-inter",
  weight: ["400", "500", "600", "700"],
  display: "swap",
});

export const viewport: Viewport = {
  themeColor: "#0a0a0a",
  width: "device-width",
  initialScale: 1,
};

export const metadata: Metadata = {
  metadataBase: new URL(SITE_CONFIG.url),
  title: {
    default: `${SITE_CONFIG.brand} — ${SITE_CONFIG.tagline}`,
    template: `%s — ${SITE_CONFIG.brand}`,
  },
  description: SITE_CONFIG.description,
  keywords: [
    "lunettes de soleil",
    "lunettes premium",
    "CHROMÉS HEARTS",
    "lunettes anti lumière bleue",
    "commande WhatsApp",
    "livraison Dakar",
  ],
  authors: [{ name: SITE_CONFIG.brand }],
  openGraph: {
    type: "website",
    locale: "fr_FR",
    url: SITE_CONFIG.url,
    siteName: SITE_CONFIG.brand,
    title: `${SITE_CONFIG.brand} — ${SITE_CONFIG.tagline}`,
    description: SITE_CONFIG.description,
  },
  twitter: {
    card: "summary_large_image",
    title: `${SITE_CONFIG.brand} — ${SITE_CONFIG.tagline}`,
    description: SITE_CONFIG.description,
  },
  robots: {
    index: true,
    follow: true,
  },
};

export default function RootLayout({ children }: { children: ReactNode }) {
  const productJsonLd = {
    "@context": "https://schema.org",
    "@type": "Product",
    name: SITE_CONFIG.brand,
    description: SITE_CONFIG.description,
    offers: {
      "@type": "Offer",
      priceCurrency: "XOF",
      price: SITE_CONFIG.price,
      availability: "https://schema.org/InStock",
      url: SITE_CONFIG.url,
    },
  };

  return (
    <html lang="fr" className={`${fraunces.variable} ${inter.variable}`}>
      <body id="top">
        {/* Données structurées Produit — aide au référencement (rich snippets) */}
        <script
          type="application/ld+json"
          // eslint-disable-next-line react/no-danger
          dangerouslySetInnerHTML={{ __html: JSON.stringify(productJsonLd) }}
        />
        <MetaPixel />
        {children}
      </body>
    </html>
  );
}
