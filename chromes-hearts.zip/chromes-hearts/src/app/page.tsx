import { Header } from "@/components/Header";
import { Hero } from "@/components/Hero";
import { Gallery } from "@/components/Gallery";
import { WhyChooseUs } from "@/components/WhyChooseUs";
import { Testimonials } from "@/components/Testimonials";
import { FAQ } from "@/components/FAQ";
import { OrderForm } from "@/components/OrderForm";
import { Footer } from "@/components/Footer";
import { StickyOrderBar } from "@/components/StickyOrderBar";

export default function HomePage() {
  return (
    <>
      <Header />
      <main>
        <Hero />
        <Gallery />
        <WhyChooseUs />
        <Testimonials />
        <FAQ />
        <OrderForm />
      </main>
      <Footer />
      <StickyOrderBar />
    </>
  );
}
