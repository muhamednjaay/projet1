import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./src/app/**/*.{ts,tsx}",
    "./src/components/**/*.{ts,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        // Système de couleurs "hallmark" — noir profond / or / blanc cassé
        noir: {
          DEFAULT: "#0a0a0a",
          soft: "#141310",
          card: "#1a1814",
          line: "#2a2620",
        },
        or: {
          DEFAULT: "#c9a227",
          light: "#e8cf7a",
          dark: "#8b6f1f",
          bright: "#f4d675",
        },
        creme: {
          DEFAULT: "#f5f1e8",
          muted: "#c9c4b6",
          dim: "#8a8578",
        },
      },
      fontFamily: {
        display: ["var(--font-fraunces)", "serif"],
        body: ["var(--font-inter)", "sans-serif"],
      },
      backgroundImage: {
        "gold-gradient": "linear-gradient(135deg, #8b6f1f 0%, #e8cf7a 45%, #c9a227 70%, #8b6f1f 100%)",
        "gold-line": "linear-gradient(90deg, transparent, #c9a227, transparent)",
        "noir-radial": "radial-gradient(ellipse at top, #1a1814 0%, #0a0a0a 60%)",
      },
      boxShadow: {
        gold: "0 0 40px -10px rgba(201, 162, 39, 0.35)",
        "gold-sm": "0 0 20px -6px rgba(201, 162, 39, 0.45)",
      },
      keyframes: {
        "fade-up": {
          "0%": { opacity: "0", transform: "translateY(24px)" },
          "100%": { opacity: "1", transform: "translateY(0)" },
        },
        shimmer: {
          "0%": { backgroundPosition: "-200% 0" },
          "100%": { backgroundPosition: "200% 0" },
        },
        "pulse-ring": {
          "0%": { boxShadow: "0 0 0 0 rgba(201, 162, 39, 0.45)" },
          "100%": { boxShadow: "0 0 0 16px rgba(201, 162, 39, 0)" },
        },
      },
      animation: {
        "fade-up": "fade-up 0.8s cubic-bezier(0.22, 1, 0.36, 1) both",
        shimmer: "shimmer 3s linear infinite",
        "pulse-ring": "pulse-ring 1.8s cubic-bezier(0.4, 0, 0.6, 1) infinite",
      },
    },
  },
  plugins: [],
};

export default config;
