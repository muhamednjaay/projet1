# CHROMÉS HEARTS — Boutique e-commerce mono-produit

Site e-commerce premium (Next.js 15 · TypeScript · Tailwind CSS) pour une seule
paire de lunettes, pensé pour transformer le trafic Facebook/Instagram Ads en
commandes WhatsApp.

## 🚀 Démarrage rapide

```bash
npm install
npm run dev
```

Ouvrez [http://localhost:3000](http://localhost:3000). Le site fonctionne
immédiatement, avec des visuels de remplacement (SVG dorés) à la place de vos
vraies photos/vidéo — voir la section "Remplacer les visuels" ci-dessous.

## ⚙️ Configuration (obligatoire avant mise en ligne)

Copiez `.env.example` en `.env.local` puis renseignez :

```bash
cp .env.example .env.local
```

| Variable | Description |
|---|---|
| `NEXT_PUBLIC_WHATSAPP_NUMBER` | Numéro WhatsApp qui reçoit les commandes, format international sans "+" (ex : `221771234567`) |
| `NEXT_PUBLIC_META_PIXEL_ID` | ID de votre Pixel Meta (Facebook Ads). Laissez vide pour désactiver le tracking. |
| `NEXT_PUBLIC_SITE_URL` | URL finale du site (SEO, Open Graph, sitemap) |

Le Pixel Meta est injecté depuis un seul fichier, clairement identifié :
`src/components/MetaPixel.tsx`. Rien d'autre à modifier.

## 🖼️ Remplacer les visuels par vos vraies photos/vidéo

Le projet est livré avec des illustrations SVG dorées en guise de
placeholders, pour que tout fonctionne dès `npm run dev`. Avant la mise en
ligne, remplacez :

- `public/images/gallery-1.svg` → `gallery-6.svg` : vos photos produit
  (formats conseillés : `.jpg`/`.png`/`.webp`, ratio carré ou 4:5).
  Mettez ensuite à jour les chemins dans `src/lib/constants.ts` (tableau
  `GALLERY_IMAGES`).
- `public/videos/hero.mp4` : votre vidéo de fond pour le hero (le fichier
  n'existe pas encore dans le dépôt — déposez-le simplement à cet endroit,
  le composant `Hero.tsx` le détecte automatiquement ; en son absence, un
  fond dégradé premium s'affiche à la place, sans aucune erreur).

## ✏️ Modifier les textes, prix, avis, FAQ

Tout le contenu éditable est centralisé dans **`src/lib/constants.ts`** :

- `SITE_CONFIG` : nom, accroche, prix, ancien prix, numéro WhatsApp par défaut
- `FEATURES` : section "Pourquoi choisir CHROMÉS HEARTS"
- `TESTIMONIALS` : avis clients (ajoutez/supprimez librement des entrées)
- `FAQS` : questions fréquentes
- `GALLERY_IMAGES` : images de la galerie

Aucune autre modification de code n'est nécessaire pour ces changements.

## 🧱 Architecture du projet

```
src/
  app/
    layout.tsx          → Polices, SEO, Open Graph, JSON-LD, Pixel Meta
    page.tsx             → Assemble toutes les sections de la page unique
    globals.css          → Design tokens, styles de base, utilitaires
    opengraph-image.tsx  → Image de partage générée dynamiquement
    icon.svg              → Favicon (monogramme doré)
    sitemap.ts / robots.ts
  components/
    Header.tsx            → Navigation sticky
    Hero.tsx               → Vidéo, titre, prix, CTA
    Gallery.tsx             → Galerie avec zoom plein écran
    WhyChooseUs.tsx          → Arguments de vente
    Testimonials.tsx          → Avis clients
    FAQ.tsx                    → Accordéon
    OrderForm.tsx               → Formulaire + géolocalisation + WhatsApp
    StickyOrderBar.tsx           → Barre CTA flottante (mobile)
    Footer.tsx
    MetaPixel.tsx                → Emplacement unique du Pixel Meta
    MonogramBadge.tsx              → Élément signature de la marque
    FeatureIcon.tsx                 → Icônes SVG faites main (0 dépendance)
  lib/
    constants.ts   → Tout le contenu éditable (voir ci-dessus)
    whatsapp.ts     → Construction du message + lien wa.me
    fbpixel.ts       → Envoi sécurisé d'événements au Pixel Meta
    useReveal.ts      → Animation d'apparition au scroll (IntersectionObserver)
```

Aucune librairie UI/animation superflue : uniquement Next.js, React et
Tailwind CSS. Les icônes et le monogramme sont du SVG écrit à la main.

## 📍 Fonctionnement de la géolocalisation

1. Le client clique sur **"Utiliser ma position actuelle"**.
2. Le navigateur demande l'autorisation d'accès à la position (API
   `navigator.geolocation`).
3. Si acceptée : latitude/longitude sont converties en lien Google Maps
   (`https://www.google.com/maps?q=lat,lng`) et ajoutées au message WhatsApp.
4. Si refusée ou indisponible : aucun blocage — le client peut simplement
   renseigner son adresse dans le champ texte prévu à cet effet.

## 💬 Message WhatsApp généré automatiquement

À la validation du formulaire, le site ouvre WhatsApp dans un nouvel onglet
avec un message déjà rédigé (voir `src/lib/whatsapp.ts`), au format :

```
Bonjour,
Je souhaite commander les lunettes CHROMÉS HEARTS.

Nom : ...
Téléphone : ...
Ville : ...
Quartier : ...
Adresse : ...
Position GPS : ...
Quantité : ...
Prix : ... FCFA

Je confirme ma commande.
```

Le client n'a plus qu'à appuyer sur "Envoyer".

## ☁️ Déploiement sur Vercel

1. Poussez ce projet sur un dépôt GitHub/GitLab.
2. Importez-le sur [vercel.com/new](https://vercel.com/new).
3. Renseignez les variables d'environnement (`NEXT_PUBLIC_WHATSAPP_NUMBER`,
   `NEXT_PUBLIC_META_PIXEL_ID`, `NEXT_PUBLIC_SITE_URL`) dans les paramètres du
   projet Vercel.
4. Déployez — aucune configuration supplémentaire n'est nécessaire.

## ✅ Bonnes pratiques déjà en place

- SEO complet : métadonnées, Open Graph dynamique, JSON-LD Produit,
  sitemap, robots.txt.
- Performance : polices auto-hébergées (`next/font`), images optimisées
  (`next/image`), scripts tiers chargés en différé (`next/script`).
- Accessibilité : focus visibles, labels de formulaire, navigation clavier
  dans la galerie, respect de `prefers-reduced-motion`.
- Responsive : mobile-first, barre de commande flottante dédiée au mobile.
